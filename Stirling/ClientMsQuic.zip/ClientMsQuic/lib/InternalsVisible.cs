#pragma warning disable IDE0073
//
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
//
#pragma warning restore IDE0073

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MsQuicTool")]
